package com.yss.buttons

import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isVisible

class MainActivity : AppCompatActivity() {

    lateinit var MM : Button
    lateinit var KK : Button
    lateinit var DD : Button
    lateinit var BB : Button
    lateinit var Texts : TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        MM = findViewById(R.id.MM)
        BB = findViewById(R.id.BB)
        DD = findViewById(R.id.DD)
        KK = findViewById(R.id.KK)
        Texts = findViewById(R.id.Texts)

        MM.setOnClickListener {

            MM.setBackgroundColor(Color.RED)

        }
        BB.setOnClickListener {
            BB.setBackgroundColor(Color.RED)
        }
        DD.setOnClickListener {
            DD.setBackgroundColor(Color.GREEN)
        }
        KK.setOnClickListener {
            KK.setBackgroundColor(Color.RED)
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}